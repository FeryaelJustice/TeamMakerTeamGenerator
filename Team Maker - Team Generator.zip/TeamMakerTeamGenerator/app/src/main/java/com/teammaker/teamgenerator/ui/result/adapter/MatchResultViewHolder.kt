package com.teammaker.teamgenerator.ui.result.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.teammaker.teamgenerator.databinding.ItemMatchResultBinding
import com.teammaker.teamgenerator.domain.model.MatchTeam

class MatchResultViewHolder (view: View): RecyclerView.ViewHolder(view) {
    val binding = ItemMatchResultBinding.bind(view)

    fun render(match: Pair<MatchTeam, MatchTeam>) {
        binding.tvMatchResult.text = "Juega ${match.first.team} vs ${match.second.team}"
    }
}