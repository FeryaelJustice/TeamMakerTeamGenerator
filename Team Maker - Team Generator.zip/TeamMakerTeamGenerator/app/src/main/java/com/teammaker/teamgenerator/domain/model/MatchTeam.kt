package com.teammaker.teamgenerator.domain.model

data class MatchTeam(val team: List<UserModel>)
